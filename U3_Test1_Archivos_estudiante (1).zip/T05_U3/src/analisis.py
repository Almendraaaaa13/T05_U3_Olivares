"""Complete las dos funciones antes de ejecutar el estudio."""
import numpy as np

def desplazamiento_referencia(x, L, E, A, P, q):
    """u(0)=0, EA*u'(L)=P, q uniforme. Devuelva un array en mm."""
    raise NotImplementedError("PENDIENTE: implementar la solucion analitica")

def error_puntos_medios(resultado, L, E, A, P, q):
    """Devuelva el maximo error absoluto de u_h frente a u_ref en puntos medios.
    No basta comparar los nodos: interpole u_h linealmente en cada elemento.
    """
    raise NotImplementedError("PENDIENTE: error entre nodos en mm")
